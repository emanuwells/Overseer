#!/usr/bin/env python3
"""Provisiona manifests e run.sh em ~/overseer-runners/ a partir do catálogo YAML."""

from __future__ import annotations

import argparse
import json
import os
import pathlib
import subprocess
import sys

import yaml

RUN_SH_TEMPLATE = """#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
set -a
[ -f "$HERE/../.env.overseer" ] && source "$HERE/../.env.overseer"
set +a
OVERSEER_VENV="{venv}"
"$OVERSEER_VENV/bin/overseer-agent" manifest "$HERE/manifest.yaml" --by cron
"""


def load_env_file(path: pathlib.Path) -> dict[str, str]:
    if not path.is_file():
        return {}
    env: dict[str, str] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        env[key.strip()] = value.strip()
    return env


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--catalog", required=True)
    parser.add_argument("--runners-root", default=os.path.expanduser("~/overseer-runners"))
    parser.add_argument("--venv", default=os.path.expanduser("~/overseer-venv"))
    parser.add_argument("--env-file", default="")
    parser.add_argument("--register", action="store_true")
    parser.add_argument("--catalog-json-out", default="/tmp/overseer_runner_catalog.json")
    args = parser.parse_args()

    catalog_path = pathlib.Path(args.catalog)
    runners_root = pathlib.Path(args.runners_root).expanduser()
    venv = pathlib.Path(args.venv).expanduser()
    runners_root.mkdir(parents=True, exist_ok=True)

    env_file = pathlib.Path(args.env_file) if args.env_file else runners_root / ".env.overseer"
    if args.env_file and pathlib.Path(args.env_file).is_file():
        token = load_env_file(pathlib.Path(args.env_file)).get("OVERSEER_API_TOKEN", "")
        api_url = load_env_file(pathlib.Path(args.env_file)).get("OVERSEER_API_URL", "http://127.0.0.1:8090")
        runners_root.joinpath(".env.overseer").write_text(
            f"OVERSEER_API_URL={api_url}\nOVERSEER_API_TOKEN={token}\n",
            encoding="utf-8",
        )
        os.chmod(runners_root / ".env.overseer", 0o600)

    catalog = yaml.safe_load(catalog_path.read_text(encoding="utf-8")) or {}
    pipelines = catalog.get("pipelines") or []
    created: list[dict] = []
    runner_env = load_env_file(runners_root / ".env.overseer")

    for item in pipelines:
        pid = str(item["id"])
        dest = runners_root / pid
        dest.mkdir(parents=True, exist_ok=True)

        manifest = {
            "pipeline_id": pid,
            "pipeline_name": item.get("name", pid),
            "owner": "data",
            "criticality": "medium",
            "schedule": item.get("schedule", "manual"),
            "steps": item["steps"],
        }
        dest.joinpath("manifest.yaml").write_text(
            yaml.safe_dump(manifest, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        dest.joinpath("run.sh").write_text(
            RUN_SH_TEMPLATE.format(venv=venv),
            encoding="utf-8",
        )
        os.chmod(dest / "run.sh", 0o755)

        if args.register and (venv / "bin/overseer-agent").is_file():
            env = os.environ.copy()
            env.update(runner_env)
            subprocess.run(
                [
                    str(venv / "bin/overseer-agent"),
                    "manifest",
                    str(dest / "manifest.yaml"),
                    "--register-catalog",
                    "--by",
                    "provision",
                ],
                env=env,
                check=False,
            )

        created.append(
            {
                "id": pid,
                "schedule": item.get("schedule"),
                "log": item.get("log"),
                "cron_match": item.get("cron_match"),
                "run_sh": str(dest / "run.sh"),
            }
        )

    pathlib.Path(args.catalog_json_out).write_text(
        json.dumps({"pipelines": created}, indent=2),
        encoding="utf-8",
    )
    print(f"Provisionados {len(created)} runners em {runners_root}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
