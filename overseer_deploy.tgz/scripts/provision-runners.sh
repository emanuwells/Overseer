#!/usr/bin/env bash
# Provisiona manifests e run.sh em ~/overseer-runners/ a partir do catálogo YAML.
#
# Uso:
#   bash scripts/provision-runners.sh
#   bash scripts/provision-runners.sh --register
#   bash scripts/provision-runners.sh --register --crontab
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CATALOG="${OVERSEER_RUNNERS_CATALOG:-$REPO_ROOT/deploy/runners/d4maia-pipelines.yaml}"
RUNNERS_ROOT="${OVERSEER_RUNNERS_ROOT:-$HOME/overseer-runners}"
VENV="${OVERSEER_VENV:-$HOME/overseer-venv}"
ENV_FILE="${OVERSEER_ENV_FILE:-$REPO_ROOT/.env}"

REGISTER=""
CRONTAB=""
for arg in "$@"; do
    case "$arg" in
        --register) REGISTER="--register" ;;
        --crontab) CRONTAB="--crontab" ;;
    esac
done

python3 "$REPO_ROOT/scripts/provision_runners.py" \
    --catalog "$CATALOG" \
    --runners-root "$RUNNERS_ROOT" \
    --venv "$VENV" \
    --env-file "$ENV_FILE" \
    $REGISTER

if [ "$CRONTAB" = "--crontab" ]; then
    python3 "$REPO_ROOT/scripts/update-crontab-overseer.py" \
        --catalog-json /tmp/overseer_runner_catalog.json \
        --backup-dir "$HOME/backups"
fi
